import {IRestResponse} from '../module/global/interface/IRestResponse';
import {IPagedContent} from '../module/global/interface/IPagedContent';
import {StaticData} from '../module/global/interface/StaticData';

export const StaticDataResp: IRestResponse<IPagedContent<StaticData>> = {
  message: null,
  success: true,
  data: {
    content: [
      {
        createdBy: 'SYSTEM',
        dateCreated: '19-12-20 00:00 AM GMT+01:00',
        id: 15046,
        code: 'FQ_TRAN_CURRENCY',
        value: 'EUR',
        description: 'EUROS',
        status: 'ACTIVE',
        field1: null,
        field2: null,
        field3: null,
        field4: null,
        field5: null
      },
      {
        createdBy: 'SYSTEM',
        dateCreated: '19-12-20 00:00 AM GMT+01:00',
        id: 15047,
        code: 'FQ_TRAN_CURRENCY',
        value: 'GBP',
        description: 'GREAT BRITAIN POUNDS',
        status: 'ACTIVE',
        field1: null,
        field2: null,
        field3: null,
        field4: null,
        field5: null
      },
      {
        createdBy: 'SYSTEM',
        dateCreated: '19-12-20 00:00 AM GMT+01:00',
        id: 15045,
        code: 'FQ_TRAN_CURRENCY',
        value: 'USD',
        description: 'US DOLLARS',
        status: 'ACTIVE',
        field1: null,
        field2: null,
        field3: null,
        field4: null,
        field5: null
      }
    ],
    pageable: {
      sort: {
        sorted: false,
        unsorted: true,
        empty: true
      },
      offset: 0,
      pageSize: 1000,
      pageNumber: 0,
      paged: true,
      unpaged: false
    },
    totalPages: 1,
    last: true,
    totalElements: 3,
    size: 1000,
    number: 0,
    sort: {
      sorted: false,
      unsorted: true,
      empty: true
    },
    numberOfElements: 3,
    first: true,
    empty: false
  },
  status: 200
};
