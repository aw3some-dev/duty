import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {IRestResponse} from '../interface/IRestResponse';
import {IPagedContent} from '../interface/IPagedContent';
import {StaticData} from '../interface/StaticData';
import {StaticDataCode} from '../enumeration/StaticDataCode';


@Injectable({
  providedIn: 'root'
})
export class StaticDataService {

  private STATIC_DATA_URL  = 'api/static/data';
  constructor( private http: HttpClient) { }

  getStaticData(code: StaticDataCode|string, value?: string, match?: boolean): Observable<IRestResponse<IPagedContent<StaticData>>> {
    let params  = new HttpParams();
    params = params.append('code', code.toUpperCase());
    params = params.append('size', '20000');
    if (!!value) {
      params = params.append('value', value);

      if (match !== undefined || match !== null) {
        params = params.append('match', match ? 'Y' :  'N');
      }
    }

    // TODO CHANGE URL
    return this.http.get<IRestResponse<IPagedContent<StaticData>>>(this.STATIC_DATA_URL, {params})
      .pipe(
        tap(_ => this.log('fetched static data')),
        catchError(this.handleError<IRestResponse<IPagedContent<StaticData>>>('getStaticData', null))
      );
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(error as T);
    };
  }
  /** Log a message */
  private log(message: string) {
    console.log(`StaticDataService : ${message}`);
  }
}
