import { Injectable } from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree} from '@angular/router';
import {Promise} from 'q';
import {Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {
  public static guards = [ ];
  constructor() { }

 static forPermissions(permissions: string | string[]) {
   @Injectable({
     providedIn: 'root'
   })
    class AuthGuardServiceWithPermissions {
      constructor(private authGuardService: AuthGuardService, private router: Router) { }
      // uses the parent class instance actually, but could in theory take any other deps
      canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        // checks typical activation (auth) + custom permissions

        return this.authGuardService.canActivate(route, state) && this.checkPermissions(state);
      }

      checkPermissions( state: RouterStateSnapshot) {
        console.log(permissions);

     /*   this.router.navigate(['/unauthorised'], {
          queryParams: {
            return: state.url
          }
        });*/
        return true;

       // return true;
        // return user.hasPermissions(permissions);
      }
    }

   AuthGuardService.guards.push(AuthGuardServiceWithPermissions);
   return AuthGuardServiceWithPermissions;
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):

  boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
   return true;
  }
/*  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree> | boolean | UrlTree {
    // TODO not used
    return true;
  }*/

}
