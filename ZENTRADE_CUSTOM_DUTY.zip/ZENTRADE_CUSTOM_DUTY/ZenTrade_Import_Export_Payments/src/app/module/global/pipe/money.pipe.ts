import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'money'
})
export class MoneyPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    const currency  = !!args && Array.isArray(args) && args.length > 0 ? args[0] : '';

    if (isNaN(value)) {return 0; }

    return value.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,') + currency;
  }

}
