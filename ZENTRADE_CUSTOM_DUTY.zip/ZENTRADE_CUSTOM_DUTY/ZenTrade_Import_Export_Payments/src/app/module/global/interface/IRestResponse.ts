export interface IRestResponse<T> {
  message?: string;
  success: boolean;
  data?: T;
  status: number;
}
