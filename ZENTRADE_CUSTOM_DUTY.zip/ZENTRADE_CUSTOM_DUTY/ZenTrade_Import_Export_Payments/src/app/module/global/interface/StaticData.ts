export class StaticData {
  createdBy: string;
  dateCreated: string;
  id: number;
  code: string;
  value: string;
  description: string;
  status: string;
  field1?: any;
  field2?: any;
  field3?: any;
  field4?: any;
  field5?: any;

}
