export interface AssessmentDetails {
  no: string;
  serial: string;
  year: string;
  formMNumber: string;
  portName: string;
  companyName: string;
  amount: number;
  currency: string;
}
