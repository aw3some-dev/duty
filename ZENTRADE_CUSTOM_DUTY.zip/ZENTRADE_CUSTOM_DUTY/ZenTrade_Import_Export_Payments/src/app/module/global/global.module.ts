import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './component/sidebar/sidebar.component';
import {RouterModule} from '@angular/router';
import {NgZorroAntdModule} from 'ng-zorro-antd';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MoneyPipe} from './pipe/money.pipe';





@NgModule({
  declarations: [SidebarComponent, MoneyPipe],
  imports: [
    CommonModule, RouterModule, FormsModule, ReactiveFormsModule, NgZorroAntdModule
  ],
  providers: [MoneyPipe],
  exports: [
    CommonModule, NgZorroAntdModule, RouterModule, FormsModule, SidebarComponent, ReactiveFormsModule,MoneyPipe
  ]
})
export class GlobalModule { }
