export interface PaymentBranchInfo {
  gl: Gl;
  account: Account;
  rate: Rate;
}

interface Rate {
  cashCommission: number;
  vatCommission: number;
}

interface Account {
  mc: string;
}

interface Gl {
  cash: string;
  branchInstruction: string;
}
