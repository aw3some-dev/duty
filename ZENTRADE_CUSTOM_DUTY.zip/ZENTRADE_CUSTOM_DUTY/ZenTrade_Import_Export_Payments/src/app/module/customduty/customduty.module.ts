import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportdutyverificationComponent } from './importdutyverification/importdutyverification.component';
import {CustomdutyRoutingModule} from './customduty-routing.module';
import {GlobalModule} from '../global/global.module';

import { AssessmentSearchComponent } from './importdutyverification/component/assessment-search/assessment-search.component';
import { AssessmentPaymentComponent } from './importdutyverification/component/assessment-payment/assessment-payment.component';





@NgModule({
  declarations: [ImportdutyverificationComponent, AssessmentSearchComponent, AssessmentPaymentComponent],
  imports: [
    CustomdutyRoutingModule,
    GlobalModule,
    CommonModule
  ]
})
export class CustomdutyModule { }
