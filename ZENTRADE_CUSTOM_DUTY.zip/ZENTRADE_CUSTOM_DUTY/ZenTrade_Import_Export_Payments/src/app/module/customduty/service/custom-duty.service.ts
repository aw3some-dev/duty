import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {IRestResponse} from '../../global/interface/IRestResponse';
import {catchError, tap} from 'rxjs/operators';
import {AssessmentDetails} from '../../global/interface/AssessmentDetails';
import {PaymentBranchInfo} from '../interface/paymentbranchinfo';
import {IPagedContent} from '../../global/interface/IPagedContent';
import {StaticData} from '../../global/interface/StaticData';

@Injectable({
  providedIn: 'root'
})
export class CustomDutyService {
  private  ASSESSMENT_SEARCH_API = 'api/duty/import/search';
  private  SUBMIT_ASSESSMENT_API = 'api/duty';
  private  BRANCH_INFO_API = 'api/duty/branch/information';
  constructor( private http: HttpClient) { }

  getAssessmentDetails(assessment: any): Observable<IRestResponse<AssessmentDetails>> {

    // TODO CHANGE URL and add assessment
    return this.http.post<IRestResponse<AssessmentDetails>>(this.ASSESSMENT_SEARCH_API , assessment)
      .pipe(
        tap(_ => this.log('fetched assessment details data')),
        catchError(this.handleError<IRestResponse<AssessmentDetails>>('getAssessmentDetails', null))
      );
  }

  submitAssessment(assessment: any): Observable<IRestResponse<string>>  {

    return this.http.post<IRestResponse<string>>(this.SUBMIT_ASSESSMENT_API, assessment )
      .pipe(
        tap(_ => this.log('submit assessment payment data')),
        catchError(this.handleError<IRestResponse<string>>('submitAssessment', null))
      );
  }
  getDutyBranchInformation(): Observable<IRestResponse<PaymentBranchInfo>> {

    // TODO CHANGE UR
    return this.http.get<IRestResponse<PaymentBranchInfo>>(this.BRANCH_INFO_API )
      .pipe(
        tap(_ => this.log('fetched assessment payment branch info data')),
        catchError(this.handleError<IRestResponse<PaymentBranchInfo>>('getDutyBranchInformation', null))
      );
  }
  
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(error as T);
    };
  }
  /** Log a message */
  private log(message: string) {
    console.log(`CustomDutyService : ${message}`);
  }
}
