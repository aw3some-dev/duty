import { TestBed } from '@angular/core/testing';

import { CustomDutyService } from './custom-duty.service';

describe('CustomDutyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CustomDutyService = TestBed.get(CustomDutyService);
    expect(service).toBeTruthy();
  });
});
