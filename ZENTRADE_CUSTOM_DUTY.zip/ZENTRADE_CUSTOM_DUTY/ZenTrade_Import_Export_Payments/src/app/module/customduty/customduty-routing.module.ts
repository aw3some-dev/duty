import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {ImportdutyverificationComponent} from './importdutyverification/importdutyverification.component';
import {AuthGuardService} from '../global/service/authguard.service';

const routes: Routes = [
  { path: 'import-duty-verification', component : ImportdutyverificationComponent,
    canActivate: [ AuthGuardService.forPermissions(['permission1', 'permission2']) ]  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomdutyRoutingModule { }
