import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentPaymentComponent } from './assessment-payment.component';

describe('AssessmentPaymentComponent', () => {
  let component: AssessmentPaymentComponent;
  let fixture: ComponentFixture<AssessmentPaymentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssessmentPaymentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessmentPaymentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
