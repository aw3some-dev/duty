import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportdutyverificationComponent } from './importdutyverification.component';

describe('ImportdutyverificationComponent', () => {
  let component: ImportdutyverificationComponent;
  let fixture: ComponentFixture<ImportdutyverificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportdutyverificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportdutyverificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
