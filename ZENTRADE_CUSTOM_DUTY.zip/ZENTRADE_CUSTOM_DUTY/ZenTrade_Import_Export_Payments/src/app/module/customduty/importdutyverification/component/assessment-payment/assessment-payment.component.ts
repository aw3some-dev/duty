import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {StaticData} from '../../../../global/interface/StaticData';
import {StaticDataService} from '../../../../global/service/static-data.service';
import {AbstractControl, FormControl, FormGroup, ValidatorFn, Validators} from '@angular/forms';
import {environment} from '../../../../../../environments/environment';
import {AssessmentDetails} from '../../../../global/interface/AssessmentDetails';
import {MoneyPipe} from '../../../../global/pipe/money.pipe';
import {PaymentMode} from '../../../interface/paymentmode';
import {NzMessageService} from 'ng-zorro-antd';
import {CustomDutyService} from '../../../service/custom-duty.service';
import {PaymentBranchInfo} from '../../../interface/paymentbranchinfo';
import {StaticDataCode} from '../../../../global/enumeration/StaticDataCode';

@Component({
  selector: 'app-assessment-payment',
  templateUrl: './assessment-payment.component.html',
  styleUrls: ['./assessment-payment.component.css']
})
export class AssessmentPaymentComponent implements OnInit {
  loading = {
    paymentMode: false,
    payingAssessment: false
  };
  validControls = {
    paymentSlipNumber: true
  };
  @Input('paymentBranchInfo')
  paymentBranchInfo: PaymentBranchInfo;

  assessmentTable: {
    key: number,
    name: string,
    value: string,
  }[] = [];

  paymentsData: {
    key: number,
    keyName: string,
    name: string,
    value: number,
  }[] = [];

  @Output('paymentDone')
  paymentDone = new EventEmitter();

  @Input('assessmentDetails')
  assessmentDetails: AssessmentDetails;

  typeInCustomerDebitAcctPaymentModes  = [PaymentMode.CHEQUE + '', PaymentMode.CUSTOMER_INSTRUCTION + ''];

  paymentSlipNumberModes  =  [PaymentMode.MC + '', PaymentMode.CASH + '', PaymentMode.CHEQUE + ''];

  paymentModes: StaticData[] = [];
  assessmentPaymentForm = new FormGroup({
    formMRequired : new FormControl(false, []),
    paarNumber: new FormControl('', [Validators.minLength(2)]),
    paymentMode: new FormControl('', [Validators.required]),
    billOfEntryNo: new FormControl('', [Validators.required, Validators.minLength(2)]),
    debitAccount: new FormControl('', [Validators.required]),
    depositor: new FormControl('', [Validators.required]),
    narration: new FormControl('', [Validators.required]),
    paymentSlipNumber: new FormControl('', [Validators.required]),
    payWithNddc: new FormControl(false, []),
    certificateNumber: new FormControl('', []),
    certificateAmount: new FormControl('', []),
  });
  constructor(private  staticDataService: StaticDataService,
              private message: NzMessageService,
              private customDutyService: CustomDutyService
              ) { }

  private computePaymentsData(dutyAmount: number, paymentMode: string) {
     this.paymentsData  = [];
     this.paymentsData.push({key: 1, keyName: 'dutyAmount', name: 'Duty Amount',
       value: dutyAmount});
     const {cashCommission, vatCommission}  = this.paymentBranchInfo.rate;
     switch (paymentMode) {
      case PaymentMode.CASH:
        this.paymentsData.push({key: 2, keyName: 'cashCommission', name: 'Cash Commission',
          value: dutyAmount * cashCommission});
        this.paymentsData.push({key: 3, keyName: 'vatOnCashCommission', name: 'VAT on Cash Commission',
          value: dutyAmount * cashCommission * vatCommission });
        break;
      default :
        // console.log('no Match');
    }

     const totalAmountToDebit  = this.paymentsData.reduce((acc, payment) => acc + payment.value, 0);

     this.paymentsData.push({key: 4, keyName: 'amountToDebit', name: 'Amount To Debit',
      value: totalAmountToDebit});

  }
  ngOnInit() {
    this.loading.paymentMode = true;
    this.assessmentPaymentForm.controls.debitAccount.disable();
    this.extractAssessmentTable();
    this.computePaymentsData(
      this.assessmentDetails.amount,
      this.assessmentPaymentForm.controls.paymentMode.value);
    // console.log(this.assessmentTable);
    this.staticDataService.getStaticData(StaticDataCode.OTHER_MODE_OF_PAYMENT)
      .subscribe((resp) => {
        this.loading.paymentMode = false;
        if (resp.success && resp.data.content) {
          this.paymentModes = resp.data.content;
        }
      });
  }

  private extractAssessmentTable() {
    this.assessmentTable = [];
    this.assessmentTable.push({key: 1, name: 'Number', value: this.assessmentDetails.no});
    this.assessmentTable.push({key: 2, name: 'Serial', value: this.assessmentDetails.serial});
    this.assessmentTable.push({key: 3, name: 'Year', value: this.assessmentDetails.year});
    this.assessmentTable.push({key: 4, name: 'Form M  Number', value: this.assessmentDetails.formMNumber});
    this.assessmentTable.push({key: 5, name: 'Customs Area', value: this.assessmentDetails.portName});
    this.assessmentTable.push({key: 6, name: 'Company Name', value: this.assessmentDetails.companyName});
    this.assessmentTable.push({
      key: 7, name: 'Amount',
      value: new MoneyPipe().transform(this.assessmentDetails.amount) + ' ' + this.assessmentDetails.currency
    });
  }

  formMRequiredChange(formMRequired: boolean) {
    // console.log(this.assessmentPaymentForm.controls);
   //  debugger;
    const paarValidators: ValidatorFn[] = [Validators.minLength(2)];
    // WHEN FORM M REQUIRED PAAR IS REQUIRED
    if (formMRequired) {
      paarValidators.push(Validators.required);
    }
    this.assessmentPaymentForm.controls.paarNumber.setValidators(paarValidators);
    this.assessmentPaymentForm.controls.paarNumber.updateValueAndValidity();
  }

  paymentModeChanged(paymentMode: string) {
    paymentMode = paymentMode.trim();
    //  WHEN CASH, MC , CHEQUE  THEN THIS IS COMPULSORY
    const paymentSlipValidators: ValidatorFn[] = [];
    this.validControls.paymentSlipNumber = false;
    if (this.paymentSlipNumberModes.indexOf(paymentMode) > -1) {
      paymentSlipValidators.push(Validators.required);
      this.validControls.paymentSlipNumber = true;
    }
    this.assessmentPaymentForm.controls.paymentSlipNumber.setValidators(paymentSlipValidators);
    this.assessmentPaymentForm.controls.paymentSlipNumber.updateValueAndValidity();

    this.handlePaymentModeChangeForDebitAccount(paymentMode);
    const formControls = this.assessmentPaymentForm.controls;

    const amount  = formControls.payWithNddc.value
    &&  formControls.certificateAmount ? (this.assessmentDetails.amount - formControls.certificateAmount.value)
      : this.assessmentDetails.amount;
    this.computePaymentsData(amount, paymentMode);

  }

  private handlePaymentModeChangeForDebitAccount(paymentMode: string) {
    const debitAccountValidators: ValidatorFn[] = [Validators.required];
    /*    CUSTOMER INSTRUCTION AND CHEQUE

        TYPE ACCOUNT NUMBER*/
    this.assessmentPaymentForm.controls.debitAccount.enable();
    this.assessmentPaymentForm.controls.debitAccount.patchValue('');
    if (this.typeInCustomerDebitAcctPaymentModes.indexOf(paymentMode) > -1) {
      debitAccountValidators.push(Validators.pattern(environment.regrex.customerAccount));
    } else {
      this.assessmentPaymentForm.controls.debitAccount.disable();
      let accountNumberForBranch = '';
      /*  PAYMENT MODE
        CASH
        PREPOPULATE GL ACCOUNT
        BRANCH INSTRUCTIOIN
        PREPOPULATE GL ACCOUNT  WITH THE CORRESPONDING GL
        MC
        POPULATE ACCOUNT FOR BRANCH MC*/
      debugger;
      switch (paymentMode) {
        case PaymentMode.CASH:
          accountNumberForBranch = this.paymentBranchInfo.gl.cash;
          break;
        case PaymentMode.BRANCH_INSTRUCTION:
          accountNumberForBranch = this.paymentBranchInfo.gl.branchInstruction;
          break;
        case PaymentMode.MC:
          accountNumberForBranch = this.paymentBranchInfo.account.mc;
          break;
        default :
          console.log('no Match');
      }
      this.assessmentPaymentForm.controls.debitAccount.patchValue(accountNumberForBranch);
    }

    this.assessmentPaymentForm.controls.debitAccount.setValidators(debitAccountValidators);
    this.assessmentPaymentForm.controls.debitAccount.updateValueAndValidity();
  }
  amountFormater = (value: number) => {
    if (!value) { return 0; }
    return `${new MoneyPipe().transform(value, ' ' + this.assessmentDetails.currency)}`;
  }
  amountParser = (value: string) => value.replace(this.assessmentDetails.currency, '');


  payWithNddcChange(payWithNddc: boolean) {
    //  recompute amount
    const certificateNumberValidators: ValidatorFn[] = [];
    const certificateAmountNumberValidators: ValidatorFn[] = [];
    if (payWithNddc) {
      certificateNumberValidators.push(Validators.required);
      certificateAmountNumberValidators.push(Validators.required);
      certificateAmountNumberValidators.push(Validators.min(1));
      certificateAmountNumberValidators.push(Validators.max(this.assessmentDetails.amount));
    }

    this.assessmentPaymentForm.controls.certificateNumber.setValidators(certificateNumberValidators);
    this.assessmentPaymentForm.controls.certificateAmount.setValidators(certificateAmountNumberValidators);

    this.assessmentPaymentForm.controls.certificateNumber.updateValueAndValidity();
    this.assessmentPaymentForm.controls.certificateAmount.updateValueAndValidity();


    this.paymentModeChanged(this.assessmentPaymentForm.controls.paymentMode.value);
  }

  submitPaymentDetails(assessmentPaymentForm: FormGroup) {

    this.toggleDisableFormControls(true);
    this.loading.payingAssessment = true;
    const id = this.message.loading('Authorising Assessment', { nzDuration: 0 }).messageId;
    //  make call here
    //  unset paywithnddc fields if not choosen
    //  unset paar if formnumber is not requred
    const  assessmentPayment  = assessmentPaymentForm.getRawValue();
    const  { formMRequired, payWithNddc }  = assessmentPayment;
    if (!formMRequired) {
      delete  assessmentPayment.paarNumber;
    }

    if (!payWithNddc) {
      delete  assessmentPayment.certificateNumber;
      delete  assessmentPayment.certificateAmount;
    }


    this.customDutyService.submitAssessment(assessmentPayment)
      .subscribe((resp) => {
        if (resp.success) {
          this.paymentDone.emit(resp.data);
        } else {
          const message  = resp.message ? resp.message : 'Unable to submit assessment';
          // TODO implement popup
          this.message.error(message);
        }
      }, (err) => {
        console.log(err);
      }, () => {
        this.loading.payingAssessment = false;
        this.message.remove(id);
      });

  }
  toggleDisableFormControls(disable: boolean) {
    for (const control in this.assessmentPaymentForm.controls) {
      if (disable) {
        this.assessmentPaymentForm.controls[control].disable();
      } else {
        this.assessmentPaymentForm.controls[control].enable();
      }
    }
  }
  changedCertificateAmount($event) {
    const paymentModeControl: AbstractControl = this.assessmentPaymentForm.controls.paymentMode;


    // if (!certificateAmountControl.valid) { return ; }

    this.paymentModeChanged(paymentModeControl.value);
  }
}
