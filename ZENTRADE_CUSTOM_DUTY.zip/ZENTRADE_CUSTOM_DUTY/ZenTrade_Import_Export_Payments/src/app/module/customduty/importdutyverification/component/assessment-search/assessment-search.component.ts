import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import * as differenceInCalendarDays from 'date-fns/difference_in_calendar_days';
import {StaticData} from '../../../../global/interface/StaticData';
import {NzMessageService, NzOptionComponent} from 'ng-zorro-antd';
import {CustomDutyService} from '../../../service/custom-duty.service';
@Component({
  selector: 'app-assessment-search',
  templateUrl: './assessment-search.component.html',
  styleUrls: ['./assessment-search.component.css']
})
export class AssessmentSearchComponent implements OnInit {
  loading = {
    searchingForAssessment : false
  };

  @Input('assessmentPortsLoading')
  set assessmentPortsLoading(assessmentPortsLoading: boolean) {
    this._assessmentPortsLoading = assessmentPortsLoading;
  }

  @Output('assessmentSearchDone')
  assessmentSearchDone = new EventEmitter();

  private _assessmentPortsLoading: boolean;

  @Input('assessmentPorts')
  set assessmentPorts(assessmentPorts: StaticData[]) {
    this._assessmentPorts = assessmentPorts;
  }

  private _assessmentPorts: StaticData[];

  today = new Date();

  assessmentSearchForm = new FormGroup({
    assessmentYear : new FormControl('', [Validators.required]),
    assessmentSerial: new FormControl('', [Validators.required]),
    assessmentNumber: new FormControl('', [Validators.required]),
    assessmentPort: new FormControl('', [Validators.required]),
    assessmentPartial: new FormControl('', [Validators.required]),
  });
  
  constructor(private message: NzMessageService, private customDutyService: CustomDutyService) { }

  disabledDate = (current: Date): boolean => {
    // Can not select days greater tha today
    return differenceInCalendarDays(current, this.today) > 0;
  }

  customFilterOption(input?: string, option?: NzOptionComponent): boolean {

    if (!input) {
      return false;
    }

    if (!option) {
      return false;
    }
    const lInput = input.toLocaleLowerCase();
    
    return (option.nzValue.includes(input) || option.nzLabel.toLocaleLowerCase().includes(lInput));

  }

  toggleDisableFormControls(disable: boolean) {
    for (const control in this.assessmentSearchForm.controls) {
      if (disable) {
        this.assessmentSearchForm.controls[control].disable();
      } else {
        this.assessmentSearchForm.controls[control].enable();
      }
    }
  }

  private searchAssessment(assessment: any) {
    const id = this.message.loading('Searching for assessment..', { nzDuration: 0 }).messageId;
    setTimeout(() => {

      this.customDutyService.getAssessmentDetails(assessment)
        .subscribe((resp) => {
          this.message.remove(id);
          this.loading.searchingForAssessment = false;
          this.toggleDisableFormControls(false);
          if (resp.success && resp.data) {
            this.assessmentSearchDone.emit(resp.data);
          }
        });

    }, 1000);

  }

  submitSearchAssessment(assessmentSearchForm: FormGroup) {
    this.loading.searchingForAssessment = true;
    this.toggleDisableFormControls(true);
    console.log(assessmentSearchForm.getRawValue());
    this.searchAssessment(assessmentSearchForm.getRawValue());
  }

  ngOnInit() {


  }

}
