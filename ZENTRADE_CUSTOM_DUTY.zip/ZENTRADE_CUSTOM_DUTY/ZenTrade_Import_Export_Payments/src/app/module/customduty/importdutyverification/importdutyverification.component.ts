import {Component, ComponentRef, OnInit, TemplateRef} from '@angular/core';

import {StaticDataService} from '../../global/service/static-data.service';

import {StaticData} from '../../global/interface/StaticData';
import {AssessmentDetails} from '../../global/interface/AssessmentDetails';
import {PaymentBranchInfo} from '../interface/paymentbranchinfo';
import {CustomDutyService} from '../service/custom-duty.service';
import {NzMessageService} from 'ng-zorro-antd';
import {StaticDataCode} from '../../global/enumeration/StaticDataCode';
@Component({
  selector: 'app-importdutyverification',
  templateUrl: './importdutyverification.component.html',
  styleUrls: ['./importdutyverification.component.css']
})
export class ImportdutyverificationComponent implements OnInit {


  current = 0;
  size = 'small';
  assessmentPorts: StaticData[] = [];


  loading = {
    assessmentPort: false
  };
  paymentBranchInfo: PaymentBranchInfo;

  // TODO remove initialized value
  assessmentDetails: AssessmentDetails = {
    no: '32323232323',
    serial: 'A',
    year: '2018',
    formMNumber: 'BA20192232312',
    portName: 'Customs Area Port Terminal Multiterminal LTD',
    companyName: 'Zenith Trade Nigeria Ltd.',
    amount: 2679901.12,
    currency: 'NGN'
  };


  constructor(private  staticDataService: StaticDataService,
              private message: NzMessageService,
              private customDutyService: CustomDutyService) { }




  ngOnInit() {
    this.loading.assessmentPort = true;
    this.staticDataService.getStaticData(StaticDataCode.PORTS)
      .subscribe((resp) => {
        this.loading.assessmentPort = false;
        if (resp.success && resp.data.content) {
          this.assessmentPorts = resp.data.content;
        }
      });
  }

  paymentDone() {
    this.current++;
  }
  
  showPaymentDetails(assessmentDetails: AssessmentDetails) {
    this.assessmentDetails = assessmentDetails;
    this.current++;
    const id = this.message.loading('Getting Branch Information For Duty Payment', { nzDuration: 0 }).messageId;
    this.customDutyService.getDutyBranchInformation()
      .subscribe((resp) => {
        this.message.remove(id);
        if (resp.success) {
          this.paymentBranchInfo = resp.data;
        }
      });

  }
}
