import { Component, OnInit } from '@angular/core';
/*import differenceInCalendarDays from 'date-fns/difference_in_calendar_days';*/
import * as differenceInCalendarDays from 'date-fns/difference_in_calendar_days';
@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {

  current = 0;
  size = 'small';
  today = new Date();
  index = 'First-content';

  paymentModes  = [
    {value: 'CASH'},
    {value: 'CUSTOMER INSTRUCTIONS'},
  ];
  customPorts  = [
    {value: 'APAPA PORT'},
    {value: 'GLK PORT BENIN'},
  ];
  listOfData = [
    {
      key: '1',
      name: 'Number',
      value: '32323232323',
    },
    {
      key: '2',
      name: 'Serial',
      value: 'A',
    },
    {
      key: '3',
      name: 'Year',
      value: '2019',
    },
    {
      key: '4',
      name: 'Form M  Number',
      value: 'BA20192232312',
    },
    {
      key: '5',
      name: 'Customs Area',
      value: 'Port Terminal Multiterminal LTD',
    },
    {
      key: '6',
      name: 'Company Name',
      value: '11 PLC',
    },
    {
      key: '7',
      name: 'Amount',
      value: '2,234,231.12 NGN',
    },
  ];
  paymentsData = [
    {
      key: '1',
      name: 'Amount To Debit',
      value: '3,234.12 NGN',
    },
    {
      key: '2',
      name: 'Cash Commission',
      value: '120.14 NGN',
    },
    {
      key: '3',
      name: 'VAT on Cash Commission',
      value: '1,234.14 NGN',
    },
    {
      key: '4',
      name: 'Total Amount',
      value: '3,612.12 NGN',
    }
  ];

  disabledDate = (current: Date): boolean => {

    // Can not select days before today and today
    return differenceInCalendarDays(current, this.today) > 0;
  }
  onSelectedAccount(accountNumber: string) {
    console.log(accountNumber);

  }

  pre(): void {
    this.current -= 1;
    this.changeContent();
  }

  next(): void {
    this.current += 1;
    this.changeContent();
  }

  done(): void {
    console.log('done');
  }

  changeContent(): void {
    switch (this.current) {
      case 0: {
        this.index = 'First-content';
        break;
      }
      case 1: {
        this.index = 'Second-content';
        break;
      }
      case 2: {
        this.index = 'third-content';
        break;
      }
      default: {
        this.index = 'error';
      }
    }
  }



  constructor() { }

  ngOnInit() {
  }
}
