import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AuthGuardService} from './module/global/service/authguard.service';


const routes: Routes = [
  { path: 'unauthorised', pathMatch: 'full',    loadChildren: () => import('./pages/welcome/welcome.module').then(m => m.WelcomeModule)},
  { path: '', pathMatch: 'full', redirectTo: '/welcome',
    canActivate: [ AuthGuardService.forPermissions(['permission1', 'permission2']) ]  },
  { path: 'welcome',
    canActivate: [ AuthGuardService.forPermissions(['permission1', 'permission2']) ],
    loadChildren: () => import('./pages/welcome/welcome.module').then(m => m.WelcomeModule) }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
