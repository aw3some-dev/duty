import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import {StaticDataResp as staticdata} from '../mocks/staticdataresp';

@Injectable({
  providedIn: 'root'
})
export class InMemoryDataService implements InMemoryDbService  {

  constructor() { }
  createDb() {

    return {staticdata};
  }
}
